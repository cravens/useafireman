# Initialize Django.
from djangoappengine import main

from google.appengine.ext.appstats.ui import app as application
