from google.appengine.api.memcache import *
