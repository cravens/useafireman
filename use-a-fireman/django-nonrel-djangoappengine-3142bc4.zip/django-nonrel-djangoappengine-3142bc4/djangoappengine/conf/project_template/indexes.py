from dbindexer import autodiscover
autodiscover()
