from {{ project_name }}.settings import *
