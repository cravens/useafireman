Changelog
=========

Version 1.6.1 (Nov 29, 2013)
-------------

* Fixed packaging issues
